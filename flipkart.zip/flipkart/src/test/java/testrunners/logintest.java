package testrunners;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;



	//@RunWith(Cucumber.class)
	@CucumberOptions(features="Featureflies/login.feature",glue="stepdefinition",dryRun=false,
			tags={"@tag1"},plugin={"com.cucumber.listener.ExtentCucumberFormatter:reports/loginresult.html"})
			
	public class logintest extends AbstractTestNGCucumberTests 
			{
				
			}		
	

