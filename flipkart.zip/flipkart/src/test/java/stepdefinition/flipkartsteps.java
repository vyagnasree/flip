package stepdefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class flipkartsteps {

	
		public static WebDriver driver;
		public String unum, upass;				



		@Given("^i open browser with url \"([^\"]*)\"$")
		public void i_open_browser_with_url(String url) 
		{
			System.setProperty("webdriver.chrome.driver", "C:\\selenium app\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get(url);  

		}

		@When("^i click on login button$")
		public void i_click_on_login_button() throws InterruptedException 
		
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@class='_1_3w1N']")).click();

		}
		
		@Then("^i should see login page$")
		public void i_should_see_login_page() throws Throwable
		{
			if (driver.findElement(By.xpath("//html/body/div[2]/div/div/div/div/div[1]/span/span")).isDisplayed()); 
			   {
				   System.out.println("login Page Launched Successfully");
			}			  
			{
				System.out.println("Login Page Failed");
			}
		}
		   

		@When("^i enter username as \"([^\"]*)\"$")
		public void i_enter_username_as(String unum) throws InterruptedException 
		{
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@class='_2IX_2- VJZDxU']")).sendKeys(unum);
			
		}

		@When("^i enter password as \"([^\"]*)\"$")
		public void enter_password_as(String upass) throws InterruptedException 
				{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys(upass);
		}

		@When("^i click on login$")
		public void i_click_on_login_button1() 
		{
			driver.findElement(By.xpath("//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")).click();
		}

		@Then("^i should see My Account$")
		public void i_should_see_my_account() throws InterruptedException 
		{
			Thread.sleep(2000);
			if(driver.findElement(By.xpath("//div[text()='My Account']")).isDisplayed())
			{
				System.out.println(" Login Successful");
			}else
			{
				System.out.println(" Login Failed");
			}
		}    

		@When("^i click on logout button$")
		public void i_click_on_logout_button()
		{
			driver.findElement(By.xpath("//div[text()='My Account']")).click();
			driver.findElement(By.xpath("//*[@id='container']/div/div[1]/div[1]/div[2]/div[3]/div/div/div[2]/div[2]/div/ul/li[10]/a")).click();
		}
		


		@When("^i close the browser$")
		public void i_close_the_browser() 
		{
			driver.close();

		}


}


